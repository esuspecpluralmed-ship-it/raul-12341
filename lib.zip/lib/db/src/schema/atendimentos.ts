import { pgTable, serial, text, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const atendimentosTable = pgTable("atendimentos", {
  id: serial("id").primaryKey(),
  municipio: text("municipio").notNull(),
  data: date("data").notNull(),
  descricao: text("descricao").notNull(),
  prioridade: text("prioridade").notNull(),
  profissao: text("profissao"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertAtendimentoSchema = createInsertSchema(atendimentosTable).omit({ id: true, createdAt: true });
export type InsertAtendimento = z.infer<typeof insertAtendimentoSchema>;
export type Atendimento = typeof atendimentosTable.$inferSelect;
