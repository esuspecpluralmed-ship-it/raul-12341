import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const profissoesTable = pgTable("profissoes", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertProfissaoSchema = createInsertSchema(profissoesTable).omit({ id: true, createdAt: true });
export type InsertProfissao = z.infer<typeof insertProfissaoSchema>;
export type Profissao = typeof profissoesTable.$inferSelect;
