import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const municipiosTable = pgTable("municipios", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertMunicipioSchema = createInsertSchema(municipiosTable).omit({ id: true, createdAt: true });
export type InsertMunicipio = z.infer<typeof insertMunicipioSchema>;
export type Municipio = typeof municipiosTable.$inferSelect;
