import { Request, Response, NextFunction } from "express";
import { db, sessionsTable, usersTable } from "@workspace/db";
import { eq, and, gt } from "drizzle-orm";

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ error: "Não autorizado" });
      return;
    }

    const token = authHeader.slice(7);
    const now = new Date();

    const [session] = await db
      .select({
        userId: sessionsTable.userId,
        role: usersTable.role,
        name: usersTable.name,
      })
      .from(sessionsTable)
      .innerJoin(usersTable, eq(sessionsTable.userId, usersTable.id))
      .where(and(eq(sessionsTable.token, token), gt(sessionsTable.expiresAt, now)));

    if (!session) {
      res.status(401).json({ error: "Sessão inválida ou expirada" });
      return;
    }

    (req as any).user = { id: session.userId, name: session.name, role: session.role };
    next();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  await requireAuth(req, res, () => {
    if ((req as any).user?.role !== "admin") {
      res.status(403).json({ error: "Acesso restrito a administradores" });
      return;
    }
    next();
  });
}
