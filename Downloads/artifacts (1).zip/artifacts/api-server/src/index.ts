import app from "./app";
import { logger } from "./lib/logger";
import { seedAdminUser, seedProfissoes, seedMunicipios } from "./lib/seed";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, async () => {
  logger.info({ port }, "Server listening");
  await seedAdminUser();
  await seedProfissoes();
  await seedMunicipios();
});
