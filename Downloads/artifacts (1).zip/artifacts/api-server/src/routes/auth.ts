import { Router } from "express";
import { db, usersTable, sessionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.post("/login", async (req, res) => {
  try {
    const { name, password } = req.body;

    if (!name || !password) {
      res.status(400).json({ error: "Usuário e senha são obrigatórios" });
      return;
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.name, name));

    if (!user || !(await bcrypt.compare(password, user.password))) {
      res.status(401).json({ error: "Usuário ou senha incorretos" });
      return;
    }

    const token = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

    await db.insert(sessionsTable).values({ userId: user.id, token, expiresAt });

    res.json({ token, id: user.id, role: user.role, name: user.name });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/logout", requireAuth, async (req, res) => {
  try {
    const token = req.headers.authorization!.slice(7);
    await db.delete(sessionsTable).where(eq(sessionsTable.token, token));
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/me", requireAuth, (req, res) => {
  const user = (req as any).user;
  res.json({ id: user.id, name: user.name, role: user.role });
});

export default router;
