import { Router } from "express";
import { db, profissoesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const profissoes = await db
      .select()
      .from(profissoesTable)
      .orderBy(profissoesTable.nome);
    res.json(profissoes.map(p => ({ ...p, createdAt: p.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/", requireAdmin, async (req, res) => {
  try {
    const { nome } = req.body;
    if (!nome || typeof nome !== "string" || nome.trim().length === 0) {
      res.status(400).json({ error: "Nome é obrigatório" });
      return;
    }
    const [profissao] = await db
      .insert(profissoesTable)
      .values({ nome: nome.trim() })
      .returning();
    res.status(201).json({ ...profissao, createdAt: profissao.createdAt.toISOString() });
  } catch (err: any) {
    if (err?.code === "23505") {
      res.status(409).json({ error: "Função já cadastrada" });
      return;
    }
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(profissoesTable).where(eq(profissoesTable.id, id));
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
