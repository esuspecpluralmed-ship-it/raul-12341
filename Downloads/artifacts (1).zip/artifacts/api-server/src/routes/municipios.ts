import { Router } from "express";
import { db, municipiosTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const municipios = await db.select().from(municipiosTable).orderBy(municipiosTable.nome);
    res.json(municipios.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/", requireAdmin, async (req, res) => {
  try {
    const { nome } = req.body;
    if (!nome || typeof nome !== "string" || nome.trim().length === 0) {
      res.status(400).json({ error: "Nome é obrigatório" });
      return;
    }
    const [municipio] = await db
      .insert(municipiosTable)
      .values({ nome: nome.trim() })
      .returning();
    res.status(201).json({ ...municipio, createdAt: municipio.createdAt.toISOString() });
  } catch (err: any) {
    if (err?.code === "23505") {
      res.status(409).json({ error: "Município já cadastrado" });
      return;
    }
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(municipiosTable).where(eq(municipiosTable.id, id));
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
