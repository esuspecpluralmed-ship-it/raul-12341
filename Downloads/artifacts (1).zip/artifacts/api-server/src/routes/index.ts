import { Router, type IRouter } from "express";
import healthRouter from "./health";
import atendimentosRouter from "./atendimentos";
import dashboardRouter from "./dashboard";
import authRouter from "./auth";
import usersRouter from "./users";
import profissoesRouter from "./profissoes";
import municipiosRouter from "./municipios";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/profissoes", profissoesRouter);
router.use("/municipios", municipiosRouter);
router.use("/atendimentos", atendimentosRouter);
router.use("/dashboard", dashboardRouter);

export default router;
