import { Router, type IRouter } from "express";
import { db, atendimentosTable } from "@workspace/db";
import { eq, and, gte, lte, sql, desc } from "drizzle-orm";
import {
  CreateAtendimentoBody,
  GetAtendimentoParams,
  DeleteAtendimentoParams,
} from "@workspace/api-zod";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const { municipio, prioridade, dataInicio, dataFim, mes, ano } = req.query;

    const conditions = [];

    if (municipio && typeof municipio === "string") {
      conditions.push(eq(atendimentosTable.municipio, municipio));
    }
    if (prioridade && typeof prioridade === "string") {
      conditions.push(eq(atendimentosTable.prioridade, prioridade));
    }
    if (dataInicio && typeof dataInicio === "string") {
      conditions.push(gte(atendimentosTable.data, dataInicio));
    }
    if (dataFim && typeof dataFim === "string") {
      conditions.push(lte(atendimentosTable.data, dataFim));
    }
    if (mes && ano) {
      const mesNum = parseInt(mes as string);
      const anoNum = parseInt(ano as string);
      const startDate = `${anoNum}-${String(mesNum).padStart(2, "0")}-01`;
      const endDate = new Date(anoNum, mesNum, 0).toISOString().split("T")[0];
      conditions.push(gte(atendimentosTable.data, startDate));
      conditions.push(lte(atendimentosTable.data, endDate));
    }

    const atendimentos = await db
      .select()
      .from(atendimentosTable)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(atendimentosTable.data), desc(atendimentosTable.createdAt));

    const result = atendimentos.map((a) => ({
      id: a.id,
      municipio: a.municipio,
      data: a.data,
      descricao: a.descricao,
      prioridade: a.prioridade,
      profissao: a.profissao ?? null,
      createdAt: a.createdAt.toISOString(),
    }));

    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAdmin, async (req, res) => {
  try {
    const body = CreateAtendimentoBody.parse(req.body);

    const [created] = await db
      .insert(atendimentosTable)
      .values({
        municipio: body.municipio,
        data: body.data,
        descricao: body.descricao,
        prioridade: body.prioridade,
      })
      .returning();

    res.status(201).json({
      id: created.id,
      municipio: created.municipio,
      data: created.data,
      descricao: created.descricao,
      prioridade: created.prioridade,
      profissao: created.profissao ?? null,
      createdAt: created.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.get("/:id", requireAuth, async (req, res) => {
  try {
    const { id } = GetAtendimentoParams.parse({ id: parseInt(req.params.id) });

    const [atendimento] = await db
      .select()
      .from(atendimentosTable)
      .where(eq(atendimentosTable.id, id));

    if (!atendimento) {
      res.status(404).json({ error: "Not found" });
      return;
    }

    res.json({
      id: atendimento.id,
      municipio: atendimento.municipio,
      data: atendimento.data,
      descricao: atendimento.descricao,
      prioridade: atendimento.prioridade,
      createdAt: atendimento.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = DeleteAtendimentoParams.parse({ id: parseInt(req.params.id) });

    await db.delete(atendimentosTable).where(eq(atendimentosTable.id, id));

    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
