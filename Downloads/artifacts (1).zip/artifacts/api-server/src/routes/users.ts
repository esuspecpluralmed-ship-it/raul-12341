import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { requireAdmin } from "../middlewares/auth";

const router = Router();

router.get("/", requireAdmin, async (req, res) => {
  try {
    const users = await db
      .select({ id: usersTable.id, name: usersTable.name, role: usersTable.role, createdAt: usersTable.createdAt })
      .from(usersTable);
    res.json(users.map(u => ({ ...u, createdAt: u.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/", requireAdmin, async (req, res) => {
  try {
    const { name, password, role } = req.body;

    if (!name || !password || !["admin", "viewer"].includes(role)) {
      res.status(400).json({ error: "Dados inválidos" });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const [user] = await db
      .insert(usersTable)
      .values({ name, password: hashedPassword, role })
      .returning({ id: usersTable.id, name: usersTable.name, role: usersTable.role });

    res.status(201).json(user);
  } catch (err: any) {
    if (err?.code === "23505") {
      res.status(409).json({ error: "Usuário já existe" });
      return;
    }
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const currentUserId = (req as any).user?.id;

    if (currentUserId === id) {
      res.status(400).json({ error: "Você não pode excluir a si mesmo" });
      return;
    }

    await db.delete(usersTable).where(eq(usersTable.id, id));
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
