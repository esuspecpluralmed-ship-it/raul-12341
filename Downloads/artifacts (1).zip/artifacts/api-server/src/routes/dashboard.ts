import { Router, type IRouter } from "express";
import { db, atendimentosTable } from "@workspace/db";
import { and, gte, lte, sql, desc, count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats", async (req, res) => {
  try {
    const now = new Date();
    const mes = req.query.mes ? parseInt(req.query.mes as string) : now.getMonth() + 1;
    const ano = req.query.ano ? parseInt(req.query.ano as string) : now.getFullYear();

    const today = now.toISOString().split("T")[0];

    const mesAnterior = mes === 1 ? 12 : mes - 1;
    const anoAnterior = mes === 1 ? ano - 1 : ano;

    const startDate = `${ano}-${String(mes).padStart(2, "0")}-01`;
    const endDate = new Date(ano, mes, 0).toISOString().split("T")[0];

    const startDateAnterior = `${anoAnterior}-${String(mesAnterior).padStart(2, "0")}-01`;
    const endDateAnterior = new Date(anoAnterior, mesAnterior, 0).toISOString().split("T")[0];

    const [todayCount] = await db
      .select({ total: count() })
      .from(atendimentosTable)
      .where(sql`${atendimentosTable.data} = ${today}`);

    const [mesCount] = await db
      .select({ total: count() })
      .from(atendimentosTable)
      .where(
        and(
          gte(atendimentosTable.data, startDate),
          lte(atendimentosTable.data, endDate)
        )
      );

    const [mesAnteriorCount] = await db
      .select({ total: count() })
      .from(atendimentosTable)
      .where(
        and(
          gte(atendimentosTable.data, startDateAnterior),
          lte(atendimentosTable.data, endDateAnterior)
        )
      );

    const porMunicipio = await db
      .select({
        municipio: atendimentosTable.municipio,
        total: count(),
      })
      .from(atendimentosTable)
      .where(
        and(
          gte(atendimentosTable.data, startDate),
          lte(atendimentosTable.data, endDate)
        )
      )
      .groupBy(atendimentosTable.municipio)
      .orderBy(sql`count(*) desc`);

    const porPrioridade = await db
      .select({
        prioridade: atendimentosTable.prioridade,
        total: count(),
      })
      .from(atendimentosTable)
      .where(
        and(
          gte(atendimentosTable.data, startDate),
          lte(atendimentosTable.data, endDate)
        )
      )
      .groupBy(atendimentosTable.prioridade);

    const altaPrioridadeRaw = await db
      .select()
      .from(atendimentosTable)
      .where(
        and(
          gte(atendimentosTable.data, startDate),
          lte(atendimentosTable.data, endDate),
          sql`${atendimentosTable.prioridade} = 'alta'`
        )
      )
      .orderBy(desc(atendimentosTable.data))
      .limit(10);

    const altaPrioridade = altaPrioridadeRaw.map((a) => ({
      id: a.id,
      municipio: a.municipio,
      data: a.data,
      descricao: a.descricao,
      prioridade: a.prioridade,
      createdAt: a.createdAt.toISOString(),
    }));

    const municipioMaiorVolume = porMunicipio.length > 0 ? porMunicipio[0].municipio : "";

    res.json({
      totalHoje: todayCount.total,
      totalMes: mesCount.total,
      totalMesAnterior: mesAnteriorCount.total,
      porMunicipio: porMunicipio.map((m) => ({ municipio: m.municipio, total: m.total })),
      porPrioridade: porPrioridade.map((p) => ({ prioridade: p.prioridade, total: p.total })),
      altaPrioridade,
      municipioMaiorVolume,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/daily", async (req, res) => {
  try {
    const now = new Date();
    const mes = req.query.mes ? parseInt(req.query.mes as string) : now.getMonth() + 1;
    const ano = req.query.ano ? parseInt(req.query.ano as string) : now.getFullYear();

    const startDate = `${ano}-${String(mes).padStart(2, "0")}-01`;
    const endDate = new Date(ano, mes, 0).toISOString().split("T")[0];

    const dailyStats = await db
      .select({
        data: atendimentosTable.data,
        total: count(),
      })
      .from(atendimentosTable)
      .where(
        and(
          gte(atendimentosTable.data, startDate),
          lte(atendimentosTable.data, endDate)
        )
      )
      .groupBy(atendimentosTable.data)
      .orderBy(atendimentosTable.data);

    res.json(dailyStats.map((d) => ({ data: d.data, total: d.total })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
