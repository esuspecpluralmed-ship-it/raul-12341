import { db, usersTable, profissoesTable, municipiosTable } from "@workspace/db";
import { count } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { logger } from "./logger";

const DEFAULT_PROFISSOES = [
  "Agente Comunitário de Saúde",
  "Coordenador",
  "Enfermeiro(a)",
  "Gerente",
  "Médico(a)",
  "Odontólogo(a)",
  "Técnico de Enfermagem",
];

export async function seedAdminUser() {
  try {
    const [{ total }] = await db.select({ total: count() }).from(usersTable);
    if (total === 0) {
      const hashedPassword = await bcrypt.hash("admin2026@", 10);
      await db.insert(usersTable).values({ name: "admin", password: hashedPassword, role: "admin" });
      logger.info("Usuário admin criado com senha padrão.");
    }
  } catch (err) {
    logger.error(err, "Erro ao criar usuário admin.");
  }
}

export async function seedProfissoes() {
  try {
    const [{ total }] = await db.select({ total: count() }).from(profissoesTable);
    if (total === 0) {
      await db.insert(profissoesTable).values(DEFAULT_PROFISSOES.map(nome => ({ nome })));
      logger.info("Funções padrão cadastradas.");
    }
  } catch (err) {
    logger.error(err, "Erro ao cadastrar funções padrão.");
  }
}

const DEFAULT_MUNICIPIOS = ["Ubajara", "Tianguá", "Jijoca de Jericoacoara", "Marco"];

export async function seedMunicipios() {
  try {
    const [{ total }] = await db.select({ total: count() }).from(municipiosTable);
    if (total === 0) {
      await db.insert(municipiosTable).values(DEFAULT_MUNICIPIOS.map(nome => ({ nome })));
      logger.info("Municípios padrão cadastrados.");
    }
  } catch (err) {
    logger.error(err, "Erro ao cadastrar municípios padrão.");
  }
}
