import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Calendar as CalendarIcon, MapPin, AlignLeft, AlertCircle, Briefcase } from "lucide-react";
import { Button, Input, Select, Label } from "./ui";
import { useAtendimentoMutations } from "@/hooks/use-atendimentos";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/auth-context";
import { useMunicipios } from "@/hooks/use-municipios";

const PRIORIDADES = [
  { value: "baixa", label: "Baixa", color: "bg-[hsl(var(--success))]" },
  { value: "media", label: "Média", color: "bg-[hsl(var(--warning))]" },
  { value: "alta", label: "Alta", color: "bg-[hsl(var(--destructive))]" }
] as const;

export default function CreateAtendimentoModal({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
  const { createAtendimento, isCreating } = useAtendimentoMutations();
  const { toast } = useToast();
  const { token } = useAuth();
  const { names: municipioNames } = useMunicipios();
  const [profissoes, setProfissoes] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    municipio: "",
    data: new Date().toISOString().split('T')[0],
    descricao: "",
    prioridade: "baixa" as "baixa" | "media" | "alta",
    profissao: "",
  });

  useEffect(() => {
    if (municipioNames.length > 0 && !formData.municipio) {
      setFormData(f => ({ ...f, municipio: municipioNames[0] }));
    }
  }, [municipioNames]);

  useEffect(() => {
    if (!isOpen) return;
    fetch("/api/profissoes", { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.ok ? r.json() : [])
      .then((data: { nome: string }[]) => setProfissoes(data.map(p => p.nome)))
      .catch(() => {});
  }, [isOpen, token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createAtendimento({
        municipio: formData.municipio,
        data: formData.data,
        descricao: formData.descricao,
        prioridade: formData.prioridade,
        profissao: formData.profissao || undefined,
      });
      toast({ title: "Sucesso!", description: "Atendimento registrado com sucesso." });
      setFormData(f => ({ ...f, descricao: "", prioridade: "baixa", profissao: "" }));
      onClose();
    } catch {
      toast({ title: "Erro", description: "Não foi possível registrar o atendimento.", variant: "destructive" });
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden"
          >
            <div className="px-6 py-4 border-b border-border flex justify-between items-center bg-gray-50/50">
              <h2 className="text-xl font-display font-bold text-foreground">Registrar Atendimento</h2>
              <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full transition-colors text-muted-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <Label className="flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" /> Município</Label>
                  <Select value={formData.municipio} onChange={(e) => setFormData({ ...formData, municipio: e.target.value })} required>
                    {municipioNames.length === 0 ? (
                      <option value="">Carregando...</option>
                    ) : (
                      municipioNames.map(m => <option key={m} value={m}>{m}</option>)
                    )}
                  </Select>
                </div>

                <div>
                  <Label className="flex items-center gap-2"><CalendarIcon className="w-4 h-4 text-primary" /> Data</Label>
                  <Input
                    type="date"
                    value={formData.data}
                    onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <Label className="flex items-center gap-2"><Briefcase className="w-4 h-4 text-primary" /> Função do Solicitante</Label>
                <Select value={formData.profissao} onChange={(e) => setFormData({ ...formData, profissao: e.target.value })}>
                  <option value="">— Selecione a função —</option>
                  {profissoes.map(p => <option key={p} value={p}>{p}</option>)}
                </Select>
              </div>

              <div>
                <Label className="flex items-center gap-2"><AlignLeft className="w-4 h-4 text-primary" /> Descrição Breve</Label>
                <textarea
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  required
                  rows={3}
                  placeholder="Descreva a demanda de suporte resolvida..."
                  className="w-full px-4 py-3 rounded-xl border border-border bg-white/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all duration-200 resize-none"
                />
              </div>

              <div>
                <Label className="flex items-center gap-2"><AlertCircle className="w-4 h-4 text-primary" /> Prioridade</Label>
                <div className="grid grid-cols-3 gap-3 mt-2">
                  {PRIORIDADES.map((p) => (
                    <label key={p.value} className={`
                      relative flex flex-col items-center p-3 rounded-xl border-2 cursor-pointer transition-all duration-200
                      ${formData.prioridade === p.value ? 'border-primary bg-primary/5 shadow-md' : 'border-border hover:border-primary/30'}
                    `}>
                      <input
                        type="radio"
                        name="prioridade"
                        value={p.value}
                        checked={formData.prioridade === p.value}
                        onChange={(e) => setFormData({ ...formData, prioridade: e.target.value as any })}
                        className="sr-only"
                      />
                      <span className={`w-3 h-3 rounded-full mb-2 ${p.color}`} />
                      <span className="text-sm font-semibold capitalize">{p.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <Button type="button" variant="ghost" onClick={onClose} className="flex-1">Cancelar</Button>
                <Button type="submit" isLoading={isCreating} className="flex-[2]">Salvar Atendimento</Button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
