import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutDashboard, History, Plus, X, Menu, LogOut, ShieldCheck, Users } from "lucide-react";
import logoPlural from "@assets/logo_plural.DOmll55q_1774011003679.png";
import { Button } from "./ui";
import CreateAtendimentoModal from "./create-atendimento-modal";
import { useAuth } from "@/contexts/auth-context";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();

  const isAdmin = user?.role === "admin";

  const navItems = [
    { path: "/", label: "Dashboard", icon: LayoutDashboard },
    { path: "/historico", label: "Histórico", icon: History },
    ...(isAdmin ? [{ path: "/admin", label: "Usuários", icon: Users }] : []),
  ];

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 glass-panel border-b border-white/40 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center gap-6">
              <Link href="/" className="flex items-center gap-3 group">
                <div className="bg-white p-2 rounded-xl shadow-sm border border-black/5 group-hover:shadow-md transition-shadow">
                  <img src={logoPlural} alt="PluralMed Logo" className="h-8 w-auto object-contain" />
                </div>
                <div className="hidden sm:block">
                  <h1 className="text-base font-display font-bold leading-tight text-primary">e-SUS PEC</h1>
                  <p className="text-[11px] text-muted-foreground font-medium leading-tight">Sistema de Registro de Atendimentos</p>
                </div>
              </Link>

              <nav className="hidden md:flex items-center gap-1">
                {navItems.map((item) => {
                  const isActive = location === item.path;
                  return (
                    <Link key={item.path} href={item.path} className={`
                      flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200
                      ${isActive ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-black/5 hover:text-foreground'}
                    `}>
                      <item.icon className={`w-4 h-4 ${isActive ? 'text-primary' : ''}`} />
                      {item.label}
                    </Link>
                  );
                })}
              </nav>
            </div>

            <div className="flex items-center gap-2">
              {isAdmin && (
                <Button onClick={() => setIsModalOpen(true)} className="hidden sm:flex group">
                  <Plus className="w-5 h-5 mr-1.5 group-hover:scale-110 transition-transform" />
                  Registrar Atendimento
                </Button>
              )}

              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-muted/50">
                {isAdmin ? (
                  <ShieldCheck className="w-4 h-4 text-primary" />
                ) : (
                  <span className="text-xs">👁️</span>
                )}
                <span className="text-sm font-semibold text-foreground">{user?.name}</span>
              </div>

              <button
                onClick={handleLogout}
                title="Sair"
                className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl transition-colors"
              >
                <LogOut className="w-5 h-5" />
              </button>

              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 md:hidden text-foreground hover:bg-black/5 rounded-lg transition-colors"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t border-border overflow-hidden bg-white/90 backdrop-blur-xl"
            >
              <div className="px-4 py-4 flex flex-col gap-2">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    href={item.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl font-semibold ${location === item.path ? 'bg-primary/10 text-primary' : 'text-foreground'}`}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </Link>
                ))}
                {isAdmin && (
                  <Button
                    className="mt-4 w-full"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      setIsModalOpen(true);
                    }}
                  >
                    <Plus className="w-5 h-5 mr-2" />
                    Registrar Atendimento
                  </Button>
                )}
                <button
                  onClick={handleLogout}
                  className="mt-2 w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-destructive hover:bg-destructive/10 rounded-xl transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  Sair
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <CreateAtendimentoModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
