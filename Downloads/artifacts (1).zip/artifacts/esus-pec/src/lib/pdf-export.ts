import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

const C = {
  primary: [27, 138, 158] as [number, number, number],
  primaryDark: [18, 95, 110] as [number, number, number],
  accent: [34, 160, 95] as [number, number, number],
  alta: [210, 50, 50] as [number, number, number],
  altaBg: [253, 236, 236] as [number, number, number],
  media: [200, 130, 0] as [number, number, number],
  mediaBg: [255, 248, 220] as [number, number, number],
  baixa: [34, 160, 95] as [number, number, number],
  baixaBg: [230, 248, 238] as [number, number, number],
  white: [255, 255, 255] as [number, number, number],
  lightGray: [246, 248, 250] as [number, number, number],
  border: [220, 225, 230] as [number, number, number],
  text: [30, 35, 40] as [number, number, number],
  muted: [100, 110, 120] as [number, number, number],
};

function fmtDate(s: string) {
  if (!s) return "";
  const [y, m, d] = s.split("-");
  return `${d}/${m}/${y}`;
}

async function toBase64(url: string): Promise<string | null> {
  try {
    const res = await fetch(url);
    const blob = await res.blob();
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
}

function sectionTitle(doc: jsPDF, text: string, y: number, pw: number, margin: number) {
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...C.primary);
  doc.text(text, margin, y);
  doc.setDrawColor(...C.primary);
  doc.setLineWidth(0.7);
  doc.line(margin, y + 1.5, margin + text.length * 1.7, y + 1.5);
  doc.setLineWidth(0.15);
  doc.setDrawColor(...C.border);
  doc.line(margin + text.length * 1.7 + 1, y + 1.5, pw - margin, y + 1.5);
}

export interface PdfAtendimento {
  id: number;
  data: string;
  municipio: string;
  profissao?: string | null;
  prioridade: string;
  descricao: string;
}

export interface PdfExportOptions {
  operador: string;
  atendimentos: PdfAtendimento[];
  filters: { municipio?: string; prioridade?: string; dataInicio?: string; dataFim?: string };
  logoUrl?: string;
}

export async function exportPDF(opts: PdfExportOptions) {
  const { operador, atendimentos, filters, logoUrl } = opts;
  const doc = new jsPDF("p", "mm", "a4");
  const pw = doc.internal.pageSize.getWidth();
  const ph = doc.internal.pageSize.getHeight();
  const M = 14;

  const logoB64 = logoUrl ? await toBase64(logoUrl) : null;
  const now = new Date();
  const dateStr = now.toLocaleDateString("pt-BR");
  const timeStr = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  // ─── HEADER ─────────────────────────────────────────────────────────────
  doc.setFillColor(...C.primaryDark);
  doc.rect(0, 0, pw, 44, "F");
  doc.setFillColor(...C.primary);
  doc.rect(0, 8, pw, 36, "F");
  doc.setFillColor(...C.accent);
  doc.rect(0, 42, pw, 2.5, "F");

  // Diagonal decorative shape
  doc.setFillColor(...C.primaryDark);
  const points = [[pw - 60, 0], [pw, 0], [pw, 44], [pw - 85, 44]];
  doc.setDrawColor(...C.primaryDark);

  if (logoB64) {
    doc.addImage(logoB64, "PNG", M, 9, 38, 17);
  } else {
    doc.setTextColor(...C.white);
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text("PLURALMED", M, 20);
    doc.setFontSize(7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(200, 230, 235);
    doc.text("Gestão de Saúde com Excelência", M, 26);
  }

  doc.setTextColor(...C.white);
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("e-SUS PEC", pw / 2, 17, { align: "center" });
  doc.setFontSize(9.5);
  doc.setFont("helvetica", "normal");
  doc.text("Sistema de Registro de Atendimentos", pw / 2, 24, { align: "center" });

  doc.setFontSize(7.5);
  doc.setTextColor(200, 230, 235);
  doc.text("Relatório Gerencial", pw / 2, 30, { align: "center" });

  doc.setFontSize(7);
  doc.setTextColor(200, 230, 235);
  doc.text(`Gerado em: ${dateStr} às ${timeStr}`, pw - M, 14, { align: "right" });
  doc.text(`Operador: ${operador}`, pw - M, 20, { align: "right" });

  let y = 54;

  // ─── FILTROS ─────────────────────────────────────────────────────────────
  doc.setFillColor(...C.lightGray);
  doc.setDrawColor(...C.border);
  doc.setLineWidth(0.3);
  doc.roundedRect(M, y - 5, pw - M * 2, 16, 2, 2, "FD");

  doc.setFontSize(7.5);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...C.primary);
  doc.text("FILTROS APLICADOS", M + 4, y + 1);

  const fp: string[] = [];
  if (filters.municipio) fp.push(`Município: ${filters.municipio}`);
  if (filters.prioridade) fp.push(`Prioridade: ${{ baixa: "Baixa", media: "Média", alta: "Alta" }[filters.prioridade] ?? filters.prioridade}`);
  if (filters.dataInicio) fp.push(`De: ${fmtDate(filters.dataInicio)}`);
  if (filters.dataFim) fp.push(`Até: ${fmtDate(filters.dataFim)}`);
  if (!fp.length) fp.push("Todos os registros (sem filtro)");

  doc.setFont("helvetica", "normal");
  doc.setTextColor(...C.text);
  doc.text(fp.join("   ·   "), M + 4, y + 8);

  y += 22;

  // ─── KPI BOXES ───────────────────────────────────────────────────────────
  const total = atendimentos.length;
  const altaC = atendimentos.filter(a => a.prioridade === "alta").length;
  const mediaC = atendimentos.filter(a => a.prioridade === "media").length;
  const baixaC = atendimentos.filter(a => a.prioridade === "baixa").length;

  const muniMap: Record<string, number> = {};
  const profMap: Record<string, number> = {};
  atendimentos.forEach(a => {
    muniMap[a.municipio] = (muniMap[a.municipio] || 0) + 1;
    if (a.profissao) profMap[a.profissao] = (profMap[a.profissao] || 0) + 1;
  });
  const topMuni = Object.entries(muniMap).sort((a, b) => b[1] - a[1])[0];

  const kpis = [
    { label: "Total", sub: "Atendimentos", val: String(total), color: C.primary, bg: [232, 245, 248] as [number, number, number] },
    { label: "Alta", sub: "Prioridade", val: String(altaC), color: C.alta, bg: C.altaBg },
    { label: "Média", sub: "Prioridade", val: String(mediaC), color: C.media, bg: C.mediaBg },
    { label: "Baixa", sub: "Prioridade", val: String(baixaC), color: C.baixa, bg: C.baixaBg },
  ];

  const bw = (pw - M * 2 - 9) / 4;
  kpis.forEach((k, i) => {
    const bx = M + i * (bw + 3);
    doc.setFillColor(...k.bg);
    doc.setDrawColor(...k.color);
    doc.setLineWidth(0.4);
    doc.roundedRect(bx, y, bw, 22, 2, 2, "FD");
    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...k.color);
    doc.text(k.val, bx + bw / 2, y + 14, { align: "center" });
    doc.setFontSize(6.5);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...C.muted);
    doc.text(k.label.toUpperCase(), bx + bw / 2, y + 19, { align: "center" });
  });

  y += 30;

  if (total > 0) {
    // ─── TOP MUNICÍPIO BANNER ─────────────────────────────────────────────
    if (topMuni) {
      doc.setFillColor(...C.primary);
      doc.setDrawColor(...C.primary);
      doc.roundedRect(M, y, pw - M * 2, 11, 2, 2, "F");
      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(...C.white);
      doc.text("🏆  Município com Maior Volume:", M + 4, y + 7);
      doc.setFont("helvetica", "normal");
      doc.text(`${topMuni[0]}  (${topMuni[1]} atendimentos · ${Math.round(topMuni[1]/total*100)}% do total)`, M + 68, y + 7);
      y += 18;
    }

    // ─── CHART: MUNICIPALITIES ────────────────────────────────────────────
    sectionTitle(doc, "ATENDIMENTOS POR MUNICÍPIO", y, pw, M);
    y += 8;

    const muniEntries = Object.entries(muniMap).sort((a, b) => b[1] - a[1]);
    const maxMuniVal = muniEntries[0]?.[1] || 1;
    const muniChartH = 8 + muniEntries.length * 12;

    doc.setFillColor(...C.lightGray);
    doc.setDrawColor(...C.border);
    doc.setLineWidth(0.2);
    doc.roundedRect(M, y, pw - M * 2, muniChartH, 2, 2, "FD");

    const barW = pw - M * 2 - 70;
    let bY = y + 8;
    muniEntries.forEach(([nome, cnt]) => {
      const filled = (cnt / maxMuniVal) * barW;
      const pct = Math.round((cnt / total) * 100);

      doc.setFontSize(7);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...C.muted);
      const label = nome.length > 22 ? nome.slice(0, 20) + "…" : nome;
      doc.text(label, M + 4, bY + 5);

      doc.setFillColor(...C.border);
      doc.roundedRect(M + 55, bY, barW, 8, 1, 1, "F");

      doc.setFillColor(...C.primary);
      doc.roundedRect(M + 55, bY, Math.max(filled, 2), 8, 1, 1, "F");

      doc.setFont("helvetica", "bold");
      doc.setTextColor(...C.white);
      if (filled > 20) doc.text(`${cnt}`, M + 55 + filled / 2, bY + 5.5, { align: "center" });

      doc.setTextColor(...C.primary);
      doc.setFont("helvetica", "bold");
      doc.text(`${cnt} (${pct}%)`, M + 55 + barW + 3, bY + 5.5);

      bY += 12;
    });
    y += muniChartH + 10;

    // ─── CHART: PRIORITY DISTRIBUTION ────────────────────────────────────
    const priEntries: [string, number, [number,number,number], [number,number,number], string][] = [
      ["alta", altaC, C.alta, C.altaBg, "Alta"],
      ["media", mediaC, C.media, C.mediaBg, "Média"],
      ["baixa", baixaC, C.baixa, C.baixaBg, "Baixa"],
    ].filter(([, cnt]) => (cnt as number) > 0) as any;

    if (priEntries.length > 0) {
      sectionTitle(doc, "DISTRIBUIÇÃO POR PRIORIDADE", y, pw, M);
      y += 8;

      const priChartH = 10 + priEntries.length * 14;
      doc.setFillColor(...C.lightGray);
      doc.setDrawColor(...C.border);
      doc.setLineWidth(0.2);
      doc.roundedRect(M, y, pw - M * 2, priChartH, 2, 2, "FD");

      let pY = y + 8;
      priEntries.forEach(([, cnt, color, bg, label]) => {
        const pct = Math.round(((cnt as number) / total) * 100);
        const filled = (pct / 100) * (pw - M * 2 - 30);

        doc.setFillColor(...(bg as [number,number,number]));
        doc.roundedRect(M + 4, pY, 28, 10, 1, 1, "F");
        doc.setFontSize(8);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(...(color as [number,number,number]));
        doc.text(label as string, M + 18, pY + 6.5, { align: "center" });

        doc.setFillColor(215, 220, 225);
        doc.roundedRect(M + 36, pY, pw - M * 2 - 50, 10, 1, 1, "F");
        doc.setFillColor(...(color as [number,number,number]));
        doc.roundedRect(M + 36, pY, Math.max(filled, 3), 10, 1, 1, "F");

        doc.setFontSize(7.5);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(255, 255, 255);
        if (filled > 30) doc.text(`${cnt} · ${pct}%`, M + 36 + filled / 2, pY + 6.5, { align: "center" });
        else {
          doc.setTextColor(...C.text);
          doc.text(`${cnt} · ${pct}%`, M + 36 + filled + 4, pY + 6.5);
        }

        pY += 14;
      });
      y += priChartH + 10;
    }

    // ─── CHART: PROFESSIONS ───────────────────────────────────────────────
    const profEntries = Object.entries(profMap).sort((a, b) => b[1] - a[1]).slice(0, 8);
    if (profEntries.length > 0) {
      sectionTitle(doc, "ATENDIMENTOS POR FUNÇÃO DO SOLICITANTE", y, pw, M);
      y += 8;

      const profChartH = 8 + profEntries.length * 11;
      doc.setFillColor(...C.lightGray);
      doc.setDrawColor(...C.border);
      doc.setLineWidth(0.2);
      doc.roundedRect(M, y, pw - M * 2, profChartH, 2, 2, "FD");

      const maxProfVal = profEntries[0]?.[1] || 1;
      const profBarW = pw - M * 2 - 80;
      let pfY = y + 8;
      profEntries.forEach(([nome, cnt]) => {
        const filled = (cnt / maxProfVal) * profBarW;
        const pct = Math.round((cnt / total) * 100);

        doc.setFontSize(6.5);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(...C.muted);
        const label = nome.length > 28 ? nome.slice(0, 26) + "…" : nome;
        doc.text(label, M + 4, pfY + 4.5);

        doc.setFillColor(...C.border);
        doc.roundedRect(M + 65, pfY, profBarW, 7, 1, 1, "F");
        doc.setFillColor(...C.accent);
        doc.roundedRect(M + 65, pfY, Math.max(filled, 2), 7, 1, 1, "F");

        doc.setFont("helvetica", "bold");
        doc.setTextColor(...C.text);
        doc.text(`${cnt} (${pct}%)`, M + 65 + profBarW + 3, pfY + 4.5);

        pfY += 11;
      });
      y += profChartH + 10;
    }
  }

  // ─── TABLE ───────────────────────────────────────────────────────────────
  sectionTitle(doc, "REGISTROS DETALHADOS", y, pw, M);
  y += 6;

  const priLabel: Record<string, string> = { alta: "Alta", media: "Média", baixa: "Baixa" };

  autoTable(doc, {
    startY: y,
    margin: { left: M, right: M },
    head: [["Data", "Município", "Função", "Prioridade", "Descrição"]],
    body: atendimentos.map(a => [
      fmtDate(a.data),
      a.municipio,
      a.profissao || "—",
      priLabel[a.prioridade] || a.prioridade,
      a.descricao,
    ]),
    styles: { fontSize: 7.5, cellPadding: 3, textColor: C.text, lineColor: C.border, lineWidth: 0.1 },
    headStyles: { fillColor: C.primary, textColor: C.white, fontStyle: "bold", fontSize: 8 },
    alternateRowStyles: { fillColor: C.lightGray },
    columnStyles: {
      0: { cellWidth: 22 },
      1: { cellWidth: 30 },
      2: { cellWidth: 36 },
      3: { cellWidth: 20, halign: "center" },
      4: { cellWidth: "auto" },
    },
    didParseCell: (data) => {
      if (data.section === "body" && data.column.index === 3) {
        const v = data.cell.raw as string;
        if (v === "Alta") { data.cell.styles.textColor = C.alta; data.cell.styles.fontStyle = "bold"; }
        else if (v === "Média") { data.cell.styles.textColor = C.media; data.cell.styles.fontStyle = "bold"; }
        else if (v === "Baixa") { data.cell.styles.textColor = C.baixa; data.cell.styles.fontStyle = "bold"; }
      }
    },
    didDrawPage: () => {
      const pg = (doc as any).internal.getCurrentPageInfo().pageNumber;
      const tot = doc.getNumberOfPages();
      doc.setFillColor(...C.primaryDark);
      doc.rect(0, ph - 11, pw, 11, "F");
      doc.setFillColor(...C.accent);
      doc.rect(0, ph - 11, pw, 1.5, "F");
      doc.setFontSize(6.5);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...C.white);
      doc.text("PluralMed · Gestão de Saúde com Excelência · e-SUS PEC", pw / 2, ph - 4, { align: "center" });
      doc.text(`Pág. ${pg} / ${tot}`, pw - M, ph - 4, { align: "right" });
      doc.text(`Operador: ${operador}  ·  ${dateStr} ${timeStr}`, M, ph - 4);
    },
  });

  const fname = `pluralmed_relatorio_${now.toLocaleDateString("pt-BR").replace(/\//g, "-")}_${now.getHours()}h${String(now.getMinutes()).padStart(2,"0")}m.pdf`;
  doc.save(fname);
}
