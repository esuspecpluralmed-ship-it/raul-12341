import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/auth-context";

export interface MunicipioEntry {
  id: number;
  nome: string;
  createdAt: string;
}

export function useMunicipios() {
  const { token } = useAuth();
  const [municipios, setMunicipios] = useState<MunicipioEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchMunicipios = async () => {
    if (!token) return;
    try {
      const res = await fetch("/api/municipios", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) setMunicipios(await res.json());
    } catch {
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMunicipios();
  }, [token]);

  return {
    municipios,
    isLoading,
    refetch: fetchMunicipios,
    names: municipios.map((m) => m.nome),
  };
}
