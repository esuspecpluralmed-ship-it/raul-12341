import { useQueryClient } from "@tanstack/react-query";
import { 
  useCreateAtendimento as useGeneratedCreate,
  useDeleteAtendimento as useGeneratedDelete,
  getListAtendimentosQueryKey,
  getGetDashboardStatsQueryKey,
  getGetDailyStatsQueryKey
} from "@workspace/api-client-react";
import type { CreateAtendimentoInput } from "@workspace/api-client-react";

export function useAtendimentoMutations() {
  const queryClient = useQueryClient();

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: [getListAtendimentosQueryKey()[0]] });
    queryClient.invalidateQueries({ queryKey: [getGetDashboardStatsQueryKey()[0]] });
    queryClient.invalidateQueries({ queryKey: [getGetDailyStatsQueryKey()[0]] });
  };

  const createMutation = useGeneratedCreate({
    mutation: {
      onSuccess: () => invalidateAll(),
    }
  });

  const deleteMutation = useGeneratedDelete({
    mutation: {
      onSuccess: () => invalidateAll(),
    }
  });

  return {
    createAtendimento: (body: CreateAtendimentoInput) => createMutation.mutateAsync({ data: body }),
    isCreating: createMutation.isPending,
    deleteAtendimento: (params: { id: number }) => deleteMutation.mutateAsync({ id: params.id }),
    isDeleting: deleteMutation.isPending,
  };
}
