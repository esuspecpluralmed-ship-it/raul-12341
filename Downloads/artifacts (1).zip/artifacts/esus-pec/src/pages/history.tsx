import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { FileDown, FileText, Trash2, Search, FilterX } from "lucide-react";
import { Card, Button, Select, Badge, Input } from "@/components/ui";
import { useListAtendimentos } from "@workspace/api-client-react";
import { useAtendimentoMutations } from "@/hooks/use-atendimentos";
import { useLocation } from "wouter";
import { formatDateString } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/auth-context";
import { useMunicipios } from "@/hooks/use-municipios";
import { exportPDF } from "@/lib/pdf-export";

export default function History() {
  const [location] = useLocation();
  const [isViewMode, setIsViewMode] = useState(false);
  const { toast } = useToast();
  const { deleteAtendimento } = useAtendimentoMutations();
  const { user } = useAuth();
  const { names: municipioNames } = useMunicipios();
  const [isExportingPDF, setIsExportingPDF] = useState(false);

  const [filters, setFilters] = useState({
    municipio: "",
    prioridade: "",
    dataInicio: "",
    dataFim: "",
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setIsViewMode(params.get("mode") === "view");
  }, [location]);

  const activeFilters = Object.fromEntries(Object.entries(filters).filter(([_, v]) => v !== ""));
  const { data: atendimentos, isLoading } = useListAtendimentos(activeFilters);

  const clearFilters = () => {
    setFilters({ municipio: "", prioridade: "", dataInicio: "", dataFim: "" });
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja remover este registro?")) return;
    try {
      await deleteAtendimento({ id });
      toast({ title: "Removido", description: "Registro removido com sucesso." });
    } catch {
      toast({ title: "Erro", description: "Falha ao remover.", variant: "destructive" });
    }
  };

  const handleExportCSV = () => {
    if (!atendimentos || atendimentos.length === 0) return;
    const headers = "ID,Município,Função,Data,Prioridade,Descrição\n";
    const rows = atendimentos.map(d =>
      `${d.id},${d.municipio},${(d as any).profissao || ""},${d.data},${d.prioridade},"${d.descricao.replace(/"/g, '""')}"`
    ).join("\n");
    const blob = new Blob(["\uFEFF" + headers + rows], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `atendimentos_${new Date().toLocaleDateString("pt-BR").replace(/\//g, "-")}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleExportPDF = async () => {
    if (!atendimentos) return;
    setIsExportingPDF(true);
    try {
      await exportPDF({
        operador: user?.name || "Sistema",
        atendimentos: atendimentos.map(a => ({
          id: a.id,
          data: a.data,
          municipio: a.municipio,
          profissao: (a as any).profissao,
          prioridade: a.prioridade,
          descricao: a.descricao,
        })),
        filters,
      });
    } catch (err) {
      toast({ title: "Erro ao gerar PDF", description: "Tente novamente.", variant: "destructive" });
    } finally {
      setIsExportingPDF(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 no-print">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground">Histórico</h2>
          <p className="text-muted-foreground mt-1">Consulte todos os atendimentos registrados</p>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={handleExportCSV} disabled={!atendimentos?.length}>
            <FileDown className="w-4 h-4 mr-2" />
            Excel / CSV
          </Button>
          <Button variant="outline" onClick={handleExportPDF} isLoading={isExportingPDF} disabled={!atendimentos?.length}>
            <FileText className="w-4 h-4 mr-2" />
            PDF PluralMed
          </Button>
        </div>
      </div>

      <Card className="p-4 sm:p-6 no-print">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1.5 block">Município</label>
            <Select value={filters.municipio} onChange={(e) => setFilters({...filters, municipio: e.target.value})}>
              <option value="">Todos</option>
              {municipioNames.map(m => <option key={m} value={m}>{m}</option>)}
            </Select>
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1.5 block">Prioridade</label>
            <Select value={filters.prioridade} onChange={(e) => setFilters({...filters, prioridade: e.target.value})}>
              <option value="">Todas</option>
              <option value="baixa">Baixa</option>
              <option value="media">Média</option>
              <option value="alta">Alta</option>
            </Select>
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1.5 block">Data Inicial</label>
            <Input type="date" value={filters.dataInicio} onChange={(e) => setFilters({...filters, dataInicio: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1.5 block">Data Final</label>
            <Input type="date" value={filters.dataFim} onChange={(e) => setFilters({...filters, dataFim: e.target.value})} />
          </div>
          <div className="flex justify-end">
            <Button variant="ghost" onClick={clearFilters} className="text-muted-foreground h-[42px] w-full lg:w-auto">
              <FilterX className="w-4 h-4 mr-2" />
              Limpar
            </Button>
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden print:shadow-none print:border-none">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-muted/50 border-b border-border text-sm text-muted-foreground font-bold tracking-wider uppercase">
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Município</th>
                <th className="px-6 py-4">Função</th>
                <th className="px-6 py-4">Prioridade</th>
                <th className="px-6 py-4">Descrição</th>
                {!isViewMode && <th className="px-6 py-4 text-right no-print">Ações</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading ? (
                Array.from({length: 5}).map((_, i) => (
                  <tr key={i}>
                    <td className="px-6 py-4"><div className="h-4 bg-muted animate-pulse rounded w-20"></div></td>
                    <td className="px-6 py-4"><div className="h-4 bg-muted animate-pulse rounded w-24"></div></td>
                    <td className="px-6 py-4"><div className="h-4 bg-muted animate-pulse rounded w-28"></div></td>
                    <td className="px-6 py-4"><div className="h-6 bg-muted animate-pulse rounded-full w-16"></div></td>
                    <td className="px-6 py-4"><div className="h-4 bg-muted animate-pulse rounded w-full max-w-md"></div></td>
                    {!isViewMode && <td className="px-6 py-4 text-right no-print"><div className="h-8 bg-muted animate-pulse rounded w-8 ml-auto"></div></td>}
                  </tr>
                ))
              ) : atendimentos?.length === 0 ? (
                <tr>
                  <td colSpan={isViewMode ? 5 : 6} className="px-6 py-12 text-center text-muted-foreground">
                    <Search className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    Nenhum atendimento encontrado com os filtros atuais.
                  </td>
                </tr>
              ) : (
                atendimentos?.map((item) => (
                  <tr key={item.id} className="hover:bg-black/[0.02] transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{formatDateString(item.data)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-foreground">{item.municipio}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                      {(item as any).profissao ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/8 text-primary text-xs font-medium">
                          {(item as any).profissao}
                        </span>
                      ) : (
                        <span className="text-muted-foreground/50">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Badge variant={item.prioridade as any}>{item.prioridade}</Badge>
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{item.descricao}</td>
                    {!isViewMode && (
                      <td className="px-6 py-4 whitespace-nowrap text-right no-print">
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)} className="text-destructive hover:bg-destructive/10">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </motion.div>
  );
}
