import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from "recharts";
import { CalendarDays, CheckCircle2, TrendingUp, TrendingDown, ArrowRight, AlertTriangle, Building2 } from "lucide-react";
import { Card, Select, Badge } from "@/components/ui";
import { useGetDashboardStats, useGetDailyStats } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { formatDateString } from "@/lib/utils";

const PRIORIDADE_COLORS = {
  baixa: "hsl(var(--success))",
  media: "hsl(var(--warning))",
  alta: "hsl(var(--destructive))"
};

export default function Dashboard() {
  const [location] = useLocation();
  const currentDate = new Date();
  const [filter, setFilter] = useState({ 
    mes: currentDate.getMonth() + 1, 
    ano: currentDate.getFullYear() 
  });

  const { data: stats, isLoading: isStatsLoading } = useGetDashboardStats(filter);
  const { data: daily, isLoading: isDailyLoading } = useGetDailyStats(filter);

  const evolucao = stats ? 
    (stats.totalMesAnterior === 0 ? 100 : Math.round(((stats.totalMes - stats.totalMesAnterior) / stats.totalMesAnterior) * 100)) 
    : 0;

  const isPositive = evolucao > 0;
  const evolucaoText = `${Math.abs(evolucao)}% vs Mês Anterior`;

  const renderSkeleton = () => (
    <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
      {[1,2,3].map(i => <div key={i} className="h-32 bg-gray-200/50 animate-pulse rounded-2xl" />)}
      <div className="h-80 bg-gray-200/50 animate-pulse rounded-2xl md:col-span-2" />
      <div className="h-80 bg-gray-200/50 animate-pulse rounded-2xl" />
    </div>
  );

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 no-print">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground">Visão Geral</h2>
          <p className="text-muted-foreground mt-1">Acompanhe as métricas de suporte do e-SUS PEC</p>
        </div>
        
        <div className="flex gap-3">
          <Select 
            value={filter.mes} 
            onChange={(e) => setFilter({ ...filter, mes: Number(e.target.value) })}
            className="w-36 bg-white"
          >
            {[1,2,3,4,5,6,7,8,9,10,11,12].map(m => (
              <option key={m} value={m}>{new Date(2000, m-1, 1).toLocaleString('pt-BR', { month: 'long' })}</option>
            ))}
          </Select>
          <Select 
            value={filter.ano} 
            onChange={(e) => setFilter({ ...filter, ano: Number(e.target.value) })}
            className="w-28 bg-white"
          >
            {[currentDate.getFullYear() - 1, currentDate.getFullYear(), currentDate.getFullYear() + 1].map(y => (
              <option key={y} value={y}>{y}</option>
            ))}
          </Select>
        </div>
      </div>

      {isStatsLoading || isDailyLoading ? renderSkeleton() : (
        <>
          {/* KPIs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-6 relative overflow-hidden group">
              <div className="absolute -right-6 -top-6 w-24 h-24 bg-primary/5 rounded-full group-hover:scale-150 transition-transform duration-500" />
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-1">Total Hoje</p>
                  <h3 className="text-4xl font-display font-bold text-foreground">{stats?.totalHoje || 0}</h3>
                </div>
                <div className="p-3 bg-primary/10 text-primary rounded-xl">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
              </div>
            </Card>

            <Card className="p-6 relative overflow-hidden group">
              <div className="absolute -right-6 -top-6 w-24 h-24 bg-accent/5 rounded-full group-hover:scale-150 transition-transform duration-500" />
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-1">Total Mês</p>
                  <h3 className="text-4xl font-display font-bold text-foreground">{stats?.totalMes || 0}</h3>
                </div>
                <div className="p-3 bg-accent/10 text-accent rounded-xl">
                  <CalendarDays className="w-6 h-6" />
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <span className={`flex items-center text-sm font-bold ${isPositive ? 'text-destructive' : 'text-success'}`}>
                  {isPositive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                  {evolucaoText}
                </span>
                <span className="text-xs text-muted-foreground">de {stats?.totalMesAnterior}</span>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-primary to-[#1085A6] text-white">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-semibold text-white/80 uppercase tracking-wider mb-1">Maior Volume</p>
                  <h3 className="text-2xl font-display font-bold">{stats?.municipioMaiorVolume || '-'}</h3>
                </div>
                <div className="p-3 bg-white/20 rounded-xl">
                  <Building2 className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="mt-6 flex items-center justify-between">
                <p className="text-sm text-white/90">Município mais ativo neste mês</p>
              </div>
            </Card>
          </div>

          {/* Charts Row 1 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="p-6 lg:col-span-2 flex flex-col">
              <h3 className="text-lg font-bold mb-6">Atendimentos por Município</h3>
              <div className="flex-1 min-h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats?.porMunicipio || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="municipio" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                    <Tooltip 
                      cursor={{fill: 'hsl(var(--muted)/0.5)'}}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar dataKey="total" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card className="p-6 flex flex-col">
              <h3 className="text-lg font-bold mb-6">Por Prioridade</h3>
              <div className="flex-1 min-h-[300px] flex justify-center items-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats?.porPrioridade || []}
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={5}
                      dataKey="total"
                      nameKey="prioridade"
                      label={({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
                        if (percent === 0) return null;
                        const RADIAN = Math.PI / 180;
                        const radius = outerRadius + 22;
                        const x = cx + radius * Math.cos(-midAngle * RADIAN);
                        const y = cy + radius * Math.sin(-midAngle * RADIAN);
                        return (
                          <text x={x} y={y} textAnchor="middle" dominantBaseline="central" className="fill-foreground" style={{ fontSize: 12, fontWeight: 700, fill: 'hsl(var(--foreground))' }}>
                            {`${(percent * 100).toFixed(0)}%`}
                          </text>
                        );
                      }}
                      labelLine={false}
                    >
                      {(stats?.porPrioridade || []).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={PRIORIDADE_COLORS[entry.prioridade as keyof typeof PRIORIDADE_COLORS]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.1)' }}
                      formatter={(value: number, name: string) => {
                        const labels: Record<string, string> = { baixa: "Baixa", media: "Média", alta: "Alta" };
                        const total = (stats?.porPrioridade || []).reduce((s, e) => s + e.total, 0);
                        const pct = total > 0 ? ((value / total) * 100).toFixed(1) : "0";
                        return [`${value} (${pct}%)`, labels[name] ?? name];
                      }}
                    />
                    <Legend verticalAlign="bottom" height={36} iconType="circle" formatter={(value) => {
                      const labels: Record<string, string> = { baixa: "Baixa", media: "Média", alta: "Alta" };
                      return <span className="font-medium text-foreground ml-1">{labels[value] ?? value}</span>;
                    }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>

          {/* Charts Row 2 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="p-6 lg:col-span-2 flex flex-col">
              <h3 className="text-lg font-bold mb-6">Evolução Diária</h3>
              <div className="flex-1 min-h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={daily || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="data" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} 
                      tickFormatter={(val) => val.split('-')[2]} // Just the day
                    />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.1)' }}
                      labelFormatter={(val) => formatDateString(val)}
                    />
                    <Line type="monotone" dataKey="total" stroke="hsl(var(--accent))" strokeWidth={3} dot={{r: 4, fill: 'hsl(var(--accent))'}} activeDot={{r: 6}} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card className="p-0 flex flex-col overflow-hidden border-destructive/20 shadow-destructive/5">
              <div className="p-6 pb-2 border-b border-border bg-red-50/50 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-destructive" />
                <h3 className="text-lg font-bold text-destructive">Alertas de Alta Prioridade</h3>
              </div>
              <div className="flex-1 p-4 overflow-y-auto max-h-[300px] space-y-3">
                {stats?.altaPrioridade?.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground p-6 text-center">
                    <CheckCircle2 className="w-10 h-10 mb-2 opacity-20" />
                    <p className="text-sm">Nenhuma demanda de alta prioridade pendente.</p>
                  </div>
                ) : (
                  stats?.altaPrioridade?.map(item => (
                    <div key={item.id} className="p-3 rounded-xl border border-destructive/20 bg-white shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-xs font-bold text-destructive bg-destructive/10 px-2 py-0.5 rounded-full">{item.municipio}</span>
                        <span className="text-xs text-muted-foreground">{formatDateString(item.data)}</span>
                      </div>
                      <p className="text-sm font-medium line-clamp-2">{item.descricao}</p>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>
        </>
      )}
    </motion.div>
  );
}
