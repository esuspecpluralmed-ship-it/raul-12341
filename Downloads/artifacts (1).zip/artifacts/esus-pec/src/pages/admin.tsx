import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Users, Plus, Trash2, ShieldCheck, Eye, X, Lock, Briefcase } from "lucide-react";
import { Card, Button, Input, Label } from "@/components/ui";
import { useAuth } from "@/contexts/auth-context";
import { useToast } from "@/hooks/use-toast";

type Tab = "usuarios" | "funcoes";

interface UserEntry {
  id: number;
  name: string;
  role: "admin" | "viewer";
  createdAt: string;
}

interface ProfissaoEntry {
  id: number;
  nome: string;
  createdAt: string;
}

export default function AdminPage() {
  const { token, user: currentUser } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<Tab>("usuarios");

  const [users, setUsers] = useState<UserEntry[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(true);
  const [showUserForm, setShowUserForm] = useState(false);
  const [userForm, setUserForm] = useState({ name: "", password: "", role: "viewer" as "admin" | "viewer" });
  const [isSubmittingUser, setIsSubmittingUser] = useState(false);

  const [profissoes, setProfissoes] = useState<ProfissaoEntry[]>([]);
  const [isLoadingProf, setIsLoadingProf] = useState(false);
  const [showProfForm, setShowProfForm] = useState(false);
  const [profForm, setProfForm] = useState({ nome: "" });
  const [isSubmittingProf, setIsSubmittingProf] = useState(false);

  const authHeader = { Authorization: `Bearer ${token}` };

  const fetchUsers = async () => {
    try {
      const res = await fetch("/api/users", { headers: authHeader });
      if (res.ok) setUsers(await res.json());
    } catch {} finally { setIsLoadingUsers(false); }
  };

  const fetchProfissoes = async () => {
    setIsLoadingProf(true);
    try {
      const res = await fetch("/api/profissoes", { headers: authHeader });
      if (res.ok) setProfissoes(await res.json());
    } catch {} finally { setIsLoadingProf(false); }
  };

  useEffect(() => { fetchUsers(); }, []);
  useEffect(() => { if (activeTab === "funcoes") fetchProfissoes(); }, [activeTab]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingUser(true);
    try {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeader },
        body: JSON.stringify(userForm),
      });
      if (!res.ok) throw new Error((await res.json()).error || "Erro ao criar");
      toast({ title: "Usuário criado!", description: `${userForm.name} adicionado.` });
      setUserForm({ name: "", password: "", role: "viewer" });
      setShowUserForm(false);
      fetchUsers();
    } catch (err: any) {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    } finally { setIsSubmittingUser(false); }
  };

  const handleDeleteUser = async (id: number, name: string) => {
    if (!confirm(`Excluir o usuário "${name}"?`)) return;
    try {
      const res = await fetch(`/api/users/${id}`, { method: "DELETE", headers: authHeader });
      if (!res.ok) throw new Error();
      toast({ title: "Usuário removido", description: `${name} foi removido.` });
      setUsers(prev => prev.filter(u => u.id !== id));
    } catch { toast({ title: "Erro", description: "Não foi possível excluir.", variant: "destructive" }); }
  };

  const handleCreateProfissao = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingProf(true);
    try {
      const res = await fetch("/api/profissoes", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeader },
        body: JSON.stringify(profForm),
      });
      if (!res.ok) throw new Error((await res.json()).error || "Erro ao criar");
      toast({ title: "Função cadastrada!", description: `"${profForm.nome}" adicionada.` });
      setProfForm({ nome: "" });
      setShowProfForm(false);
      fetchProfissoes();
    } catch (err: any) {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    } finally { setIsSubmittingProf(false); }
  };

  const handleDeleteProfissao = async (id: number, nome: string) => {
    if (!confirm(`Excluir a função "${nome}"?`)) return;
    try {
      const res = await fetch(`/api/profissoes/${id}`, { method: "DELETE", headers: authHeader });
      if (!res.ok) throw new Error();
      toast({ title: "Função removida", description: `"${nome}" foi removida.` });
      setProfissoes(prev => prev.filter(p => p.id !== id));
    } catch { toast({ title: "Erro", description: "Não foi possível excluir.", variant: "destructive" }); }
  };

  const tabs = [
    { id: "usuarios" as Tab, label: "Usuários", icon: Users },
    { id: "funcoes" as Tab, label: "Funções dos Solicitantes", icon: Briefcase },
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div>
        <h2 className="text-3xl font-display font-bold text-foreground">Administração</h2>
        <p className="text-muted-foreground mt-1">Gerencie usuários e configurações do sistema</p>
      </div>

      <div className="flex gap-2 border-b border-border">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition-all -mb-px ${
              activeTab === tab.id
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "usuarios" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">Gerencie quem pode acessar o sistema</p>
            <Button onClick={() => setShowUserForm(!showUserForm)}>
              {showUserForm ? <X className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
              {showUserForm ? "Cancelar" : "Novo Usuário"}
            </Button>
          </div>

          {showUserForm && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Plus className="w-5 h-5 text-primary" /> Novo Usuário
                </h3>
                <form onSubmit={handleCreateUser} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <Label>Nome de usuário</Label>
                    <Input value={userForm.name} onChange={e => setUserForm({ ...userForm, name: e.target.value })} placeholder="Ex: maria.silva" required />
                  </div>
                  <div>
                    <Label>Senha</Label>
                    <Input type="password" value={userForm.password} onChange={e => setUserForm({ ...userForm, password: e.target.value })} placeholder="Senha de acesso" required />
                  </div>
                  <div>
                    <Label>Perfil</Label>
                    <select
                      value={userForm.role}
                      onChange={e => setUserForm({ ...userForm, role: e.target.value as "admin" | "viewer" })}
                      className="w-full px-4 py-2.5 rounded-xl border border-border bg-white/50 text-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                    >
                      <option value="viewer">👁️ Visualizador</option>
                      <option value="admin">✍️ Administrador</option>
                    </select>
                  </div>
                  <div className="sm:col-span-3 flex justify-end">
                    <Button type="submit" isLoading={isSubmittingUser}>Salvar Usuário</Button>
                  </div>
                </form>
              </Card>
            </motion.div>
          )}

          <Card className="overflow-hidden">
            <div className="p-6 border-b border-border flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-bold">Usuários Cadastrados</h3>
              <span className="ml-auto text-sm text-muted-foreground">{users.length} usuário(s)</span>
            </div>
            {isLoadingUsers ? (
              <div className="p-8 text-center text-muted-foreground">Carregando...</div>
            ) : users.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">Nenhum usuário cadastrado.</div>
            ) : (
              <div className="divide-y divide-border">
                {users.map(u => (
                  <div key={u.id} className="flex items-center justify-between px-6 py-4 hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${u.role === "admin" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                        {u.role === "admin" ? <ShieldCheck className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{u.name}</p>
                        <p className="text-xs text-muted-foreground">{new Date(u.createdAt).toLocaleDateString("pt-BR")}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-xs font-bold px-3 py-1 rounded-full ${u.role === "admin" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                        {u.role === "admin" ? "Administrador" : "Visualizador"}
                      </span>
                      {u.id !== currentUser?.id && (
                        <button onClick={() => handleDeleteUser(u.id, u.name)} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="p-6 border border-amber-200 bg-amber-50/50">
            <div className="flex items-start gap-3">
              <Lock className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-amber-800">Como compartilhar o sistema</p>
                <p className="text-sm text-amber-700 mt-1">
                  Crie um usuário com perfil <strong>Visualizador</strong> para permitir acesso apenas de leitura.
                  Administradores têm acesso completo, incluindo registro e exclusão de atendimentos.
                </p>
              </div>
            </div>
          </Card>
        </div>
      )}

      {activeTab === "funcoes" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">Cadastre as funções dos profissionais que solicitam atendimento</p>
            <Button onClick={() => setShowProfForm(!showProfForm)}>
              {showProfForm ? <X className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
              {showProfForm ? "Cancelar" : "Nova Função"}
            </Button>
          </div>

          {showProfForm && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-primary" /> Nova Função
                </h3>
                <form onSubmit={handleCreateProfissao} className="flex gap-4 items-end">
                  <div className="flex-1">
                    <Label>Nome da função</Label>
                    <Input
                      value={profForm.nome}
                      onChange={e => setProfForm({ nome: e.target.value })}
                      placeholder="Ex: Farmacêutico(a), Fisioterapeuta..."
                      required
                    />
                  </div>
                  <Button type="submit" isLoading={isSubmittingProf}>Salvar</Button>
                </form>
              </Card>
            </motion.div>
          )}

          <Card className="overflow-hidden">
            <div className="p-6 border-b border-border flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-bold">Funções Cadastradas</h3>
              <span className="ml-auto text-sm text-muted-foreground">{profissoes.length} função(ões)</span>
            </div>
            {isLoadingProf ? (
              <div className="p-8 text-center text-muted-foreground">Carregando...</div>
            ) : profissoes.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">Nenhuma função cadastrada.</div>
            ) : (
              <div className="divide-y divide-border">
                {profissoes.map(p => (
                  <div key={p.id} className="flex items-center justify-between px-6 py-4 hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                        <Briefcase className="w-4 h-4" />
                      </div>
                      <p className="font-semibold text-foreground">{p.nome}</p>
                    </div>
                    <button onClick={() => handleDeleteProfissao(p.id, p.nome)} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="p-6 border border-blue-200 bg-blue-50/50">
            <div className="flex items-start gap-3">
              <Briefcase className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-blue-800">Como funciona</p>
                <p className="text-sm text-blue-700 mt-1">
                  As funções cadastradas aqui aparecem como opções no formulário de registro de atendimento,
                  permitindo identificar qual profissional solicitou o suporte.
                </p>
              </div>
            </div>
          </Card>
        </div>
      )}
    </motion.div>
  );
}
